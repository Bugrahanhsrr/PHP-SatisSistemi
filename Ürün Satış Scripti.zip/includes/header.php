<?php
require_once __DIR__ . '/../config.php';
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title . ' - ' : ''; ?><?php echo SITE_NAME; ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="header-content">
            <a href="<?php echo BASE_URL; ?>/" class="logo"><?php echo SITE_NAME; ?></a>
            <nav class="nav-links">
                <a href="<?php echo BASE_URL; ?>/">Ürünler</a>
                <a href="<?php echo BASE_URL; ?>/siparislerim.php">Siparişlerim</a>
            </nav>
        </div>
    </header>
    <main class="container">

