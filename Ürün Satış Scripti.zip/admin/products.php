<?php
$page_title = 'Ürünler';
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../db.php';
require_once 'includes/header.php';

$message = '';
$message_type = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
        
        if ($action === 'add' || $action === 'edit') {
            $name = trim($_POST['name'] ?? '');
            $price = floatval($_POST['price'] ?? 0);
            $description = trim($_POST['description'] ?? '');
            $image_url = trim($_POST['image_url'] ?? '');
            $category = trim($_POST['category'] ?? '');
            
            if (empty($name) || $price <= 0) {
                $message = 'Lütfen ürün adı ve fiyat bilgilerini girin.';
                $message_type = 'error';
            } else {
                try {
                    if ($action === 'add') {
                        $stmt = $pdo->prepare("INSERT INTO products (name, price, description, image_url, category) VALUES (?, ?, ?, ?, ?)");
                        $stmt->execute([$name, $price, $description, $image_url, $category]);
                        $message = 'Ürün başarıyla eklendi.';
                        $message_type = 'success';
                    } else {
                        $id = intval($_POST['id']);
                        $stmt = $pdo->prepare("UPDATE products SET name = ?, price = ?, description = ?, image_url = ?, category = ? WHERE id = ?");
                        $stmt->execute([$name, $price, $description, $image_url, $category, $id]);
                        $message = 'Ürün başarıyla güncellendi.';
                        $message_type = 'success';
                    }
                } catch (Exception $e) {
                    $message = 'Hata: ' . $e->getMessage();
                    $message_type = 'error';
                }
            }
        } elseif ($action === 'delete') {
            $id = intval($_POST['id']);
            try {
                $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
                $stmt->execute([$id]);
                $message = 'Ürün başarıyla silindi.';
                $message_type = 'success';
            } catch (Exception $e) {
                $message = 'Hata: ' . $e->getMessage();
                $message_type = 'error';
            }
        }
    }
}

// Fetch all products
$products = $pdo->query("SELECT * FROM products ORDER BY created_at DESC")->fetchAll();

// Get product for edit
$edit_product = null;
if (isset($_GET['edit'])) {
    $id = intval($_GET['edit']);
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([$id]);
    $edit_product = $stmt->fetch();
}
?>

<div class="glass-card">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
        <div>
            <h1 style="font-size: 2rem; margin-bottom: 0.5rem; color: var(--text-primary);">Ürünler</h1>
            <p style="color: var(--text-muted);">Ürün yönetimi</p>
        </div>
        <button class="btn btn-primary" onclick="openModal('productModal')">+ Yeni Ürün</button>
    </div>
    
    <?php if ($message): ?>
        <div class="alert alert-<?php echo $message_type; ?>"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>
    
    <?php if (empty($products)): ?>
        <p style="color: var(--text-muted); text-align: center; padding: 2rem;">Henüz ürün bulunmamaktadır.</p>
    <?php else: ?>
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Görsel</th>
                        <th>Ürün Adı</th>
                        <th>Kategori</th>
                        <th>Fiyat</th>
                        <th>Açıklama</th>
                        <th>İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($products as $product): ?>
                        <tr>
                            <td><?php echo $product['id']; ?></td>
                            <td>
                                <img src="<?php echo htmlspecialchars($product['image_url']); ?>" 
                                     alt="<?php echo htmlspecialchars($product['name']); ?>" 
                                     style="width: 60px; height: 60px; object-fit: cover; border-radius: var(--border-radius);"
                                     onerror="this.src='https://via.placeholder.com/60x60/101826/57F287?text=No+Image'">
                            </td>
                            <td><?php echo htmlspecialchars($product['name']); ?></td>
                            <td><?php echo htmlspecialchars($product['category']); ?></td>
                            <td><?php echo number_format($product['price'], 2); ?> ₺</td>
                            <td style="max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                                <?php echo htmlspecialchars($product['description']); ?>
                            </td>
                            <td>
                                <a href="?edit=<?php echo $product['id']; ?>" class="btn btn-secondary" style="padding: 0.5rem 1rem; font-size: 0.85rem; margin-right: 0.5rem;">Düzenle</a>
                                <form method="POST" style="display: inline;" onsubmit="return confirm('Bu ürünü silmek istediğinize emin misiniz?');">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="id" value="<?php echo $product['id']; ?>">
                                    <button type="submit" class="btn btn-secondary" style="padding: 0.5rem 1rem; font-size: 0.85rem; background: rgba(239, 68, 68, 0.2); border-color: #ef4444; color: #ef4444;">Sil</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<!-- Product Modal -->
<div id="productModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2 class="modal-title"><?php echo $edit_product ? 'Ürün Düzenle' : 'Yeni Ürün'; ?></h2>
            <button class="modal-close" onclick="closeModal('productModal')">&times;</button>
        </div>
        <form method="POST" action="">
            <input type="hidden" name="action" value="<?php echo $edit_product ? 'edit' : 'add'; ?>">
            <?php if ($edit_product): ?>
                <input type="hidden" name="id" value="<?php echo $edit_product['id']; ?>">
            <?php endif; ?>
            
            <div class="form-group">
                <label for="name">Ürün Adı</label>
                <input type="text" id="name" name="name" class="form-control" 
                       value="<?php echo $edit_product ? htmlspecialchars($edit_product['name']) : ''; ?>" 
                       required>
            </div>
            
            <div class="form-group">
                <label for="price">Fiyat (₺)</label>
                <input type="number" id="price" name="price" class="form-control" 
                       step="0.01" min="0" 
                       value="<?php echo $edit_product ? $edit_product['price'] : ''; ?>" 
                       required>
            </div>
            
            <div class="form-group">
                <label for="category">Kategori</label>
                <input type="text" id="category" name="category" class="form-control" 
                       value="<?php echo $edit_product ? htmlspecialchars($edit_product['category']) : ''; ?>">
            </div>
            
            <div class="form-group">
                <label for="image_url">Görsel URL</label>
                <input type="url" id="image_url" name="image_url" class="form-control" 
                       value="<?php echo $edit_product ? htmlspecialchars($edit_product['image_url']) : ''; ?>"
                       placeholder="https://example.com/image.jpg">
            </div>
            
            <div class="form-group">
                <label for="description">Açıklama</label>
                <textarea id="description" name="description" class="form-control" 
                          rows="4" style="resize: vertical;"><?php echo $edit_product ? htmlspecialchars($edit_product['description']) : ''; ?></textarea>
            </div>
            
            <button type="submit" class="btn btn-primary btn-block">
                <?php echo $edit_product ? 'Güncelle' : 'Ekle'; ?>
            </button>
        </form>
    </div>
</div>

<script>
    <?php if ($edit_product): ?>
        // Open modal if editing
        window.addEventListener('load', function() {
            openModal('productModal');
        });
    <?php endif; ?>
</script>

<?php require_once 'includes/footer.php'; ?>

