<?php
/**
 * Telegram Webhook Handler
 * Processes callback queries from Telegram bot
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../functions/telegram.php';

// Get webhook data
$content = file_get_contents('php://input');
$update = json_decode($content, true);

if (!isset($update['callback_query'])) {
    http_response_code(200);
    exit;
}

$callback_query = $update['callback_query'];
$callback_data = $callback_query['data'];
$message_id = $callback_query['message']['message_id'];
$chat_id = $callback_query['message']['chat']['id'];

// Process callback
$result = processTelegramCallback($pdo, $callback_data, $chat_id);

if ($result && $result['success']) {
    $bot_token = $result['bot_token'];
    
    // Answer callback query
    $url = "https://api.telegram.org/bot{$bot_token}/answerCallbackQuery";
    $data = [
        'callback_query_id' => $callback_query['id'],
        'text' => 'İşlem tamamlandı',
        'show_alert' => false
    ];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_exec($ch);
    curl_close($ch);
    
    // Edit message to show confirmation
    $url = "https://api.telegram.org/bot{$bot_token}/editMessageText";
    $data = [
        'chat_id' => $chat_id,
        'message_id' => $message_id,
        'text' => $callback_query['message']['text'] . "\n\n✅ " . $result['message'],
        'parse_mode' => 'HTML'
    ];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_exec($ch);
    curl_close($ch);
}

http_response_code(200);

