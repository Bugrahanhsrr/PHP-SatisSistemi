<?php
// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

require_once __DIR__ . '/../../config.php';
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title . ' - ' : ''; ?>Admin Panel</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/css/style.css">
    <style>
        .admin-header {
            background: var(--bg-card);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid var(--border-color);
            padding: 1rem 2rem;
            position: sticky;
            top: 0;
            z-index: 100;
            box-shadow: var(--shadow-md);
        }
        .admin-nav {
            display: flex;
            gap: 1.5rem;
            align-items: center;
        }
        .admin-nav a {
            color: var(--text-muted);
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
            padding: 0.5rem 1rem;
            border-radius: var(--border-radius);
        }
        .admin-nav a:hover,
        .admin-nav a.active {
            color: var(--accent);
            background: rgba(87, 242, 135, 0.1);
        }
        .admin-user {
            margin-left: auto;
            color: var(--text-muted);
            font-size: 0.9rem;
        }
        .admin-user a {
            color: var(--accent);
            text-decoration: none;
        }
    </style>
</head>
<body>
    <header class="admin-header">
        <div class="header-content">
            <a href="dashboard.php" class="logo">Admin Panel</a>
            <nav class="admin-nav">
                <a href="dashboard.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>">Dashboard</a>
                <a href="products.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'products.php' ? 'active' : ''; ?>">Ürünler</a>
                <a href="orders.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'orders.php' ? 'active' : ''; ?>">Siparişler</a>
                <a href="settings.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'settings.php' ? 'active' : ''; ?>">Ayarlar</a>
                <div class="admin-user">
                    <?php echo htmlspecialchars($_SESSION['admin_username'] ?? 'Admin'); ?> | 
                    <a href="logout.php">Çıkış</a>
                </div>
            </nav>
        </div>
    </header>
    <main class="container">

