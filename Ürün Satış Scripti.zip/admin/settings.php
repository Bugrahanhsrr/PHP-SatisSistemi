<?php
$page_title = 'Ayarlar';
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../db.php';
require_once 'includes/header.php';

$message = '';
$message_type = '';

// Get current admin settings
$stmt = $pdo->prepare("SELECT * FROM admin WHERE id = ?");
$stmt->execute([$_SESSION['admin_id']]);
$admin = $stmt->fetch();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $iban = trim($_POST['iban'] ?? '');
    $papara = trim($_POST['papara'] ?? '');
    $telegram_bot = trim($_POST['telegram_bot'] ?? '');
    $telegram_chatid = trim($_POST['telegram_chatid'] ?? '');
    
    // Update password if provided
    if (!empty($_POST['new_password'])) {
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'] ?? '';
        
        if ($new_password !== $confirm_password) {
            $message = 'Şifreler eşleşmiyor.';
            $message_type = 'error';
        } else {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            try {
                $stmt = $pdo->prepare("UPDATE admin SET password = ?, iban = ?, papara = ?, telegram_bot = ?, telegram_chatid = ? WHERE id = ?");
                $stmt->execute([$hashed_password, $iban, $papara, $telegram_bot, $telegram_chatid, $_SESSION['admin_id']]);
                $message = 'Ayarlar ve şifre başarıyla güncellendi.';
                $message_type = 'success';
            } catch (Exception $e) {
                $message = 'Hata: ' . $e->getMessage();
                $message_type = 'error';
            }
        }
    } else {
        try {
            $stmt = $pdo->prepare("UPDATE admin SET iban = ?, papara = ?, telegram_bot = ?, telegram_chatid = ? WHERE id = ?");
            $stmt->execute([$iban, $papara, $telegram_bot, $telegram_chatid, $_SESSION['admin_id']]);
            $message = 'Ayarlar başarıyla güncellendi.';
            $message_type = 'success';
            
            // Refresh admin data
            $stmt = $pdo->prepare("SELECT * FROM admin WHERE id = ?");
            $stmt->execute([$_SESSION['admin_id']]);
            $admin = $stmt->fetch();
        } catch (Exception $e) {
            $message = 'Hata: ' . $e->getMessage();
            $message_type = 'error';
        }
    }
}

// Test Telegram connection
if (isset($_GET['test_telegram'])) {
    require_once __DIR__ . '/../functions/telegram.php';
    
    if (!empty($admin['telegram_bot']) && !empty($admin['telegram_chatid'])) {
        $test_message = "🧪 Telegram bot test mesajı\n\nBot başarıyla bağlandı!";
        $result = sendTelegramMessage($admin['telegram_bot'], $admin['telegram_chatid'], $test_message);
        
        if ($result && isset($result['ok']) && $result['ok']) {
            $message = 'Telegram bağlantısı başarılı! Mesaj gönderildi.';
            $message_type = 'success';
        } else {
            $message = 'Telegram bağlantısı başarısız. Bot token ve Chat ID\'yi kontrol edin.';
            $message_type = 'error';
        }
    } else {
        $message = 'Telegram bot token ve Chat ID gerekli.';
        $message_type = 'error';
    }
}
?>

<div class="glass-card">
    <h1 style="font-size: 2rem; margin-bottom: 0.5rem; color: var(--text-primary);">Ayarlar</h1>
    <p style="color: var(--text-muted); margin-bottom: 2rem;">Sistem ve ödeme ayarları</p>
    
    <?php if ($message): ?>
        <div class="alert alert-<?php echo $message_type; ?>"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>
    
    <form method="POST" action="">
        <div style="margin-bottom: 2rem;">
            <h2 style="font-size: 1.3rem; margin-bottom: 1rem; color: var(--text-primary);">Ödeme Bilgileri</h2>
            
            <div class="form-group">
                <label for="iban">IBAN</label>
                <input type="text" id="iban" name="iban" class="form-control" 
                       value="<?php echo htmlspecialchars($admin['iban'] ?? ''); ?>"
                       placeholder="TR00 0000 0000 0000 0000 0000 00">
            </div>
            
            <div class="form-group">
                <label for="papara">Papara Numarası</label>
                <input type="text" id="papara" name="papara" class="form-control" 
                       value="<?php echo htmlspecialchars($admin['papara'] ?? ''); ?>"
                       placeholder="Papara numarası">
            </div>
        </div>
        
        <div style="margin-bottom: 2rem; padding-top: 2rem; border-top: 1px solid var(--border-color);">
            <h2 style="font-size: 1.3rem; margin-bottom: 1rem; color: var(--text-primary);">Telegram Bot Ayarları</h2>
            <p style="color: var(--text-muted); font-size: 0.9rem; margin-bottom: 1rem;">
                Telegram bot oluşturmak için @BotFather'dan bot token alın. Chat ID için @userinfobot kullanın.
            </p>
            
            <div class="form-group">
                <label for="telegram_bot">Bot Token</label>
                <input type="text" id="telegram_bot" name="telegram_bot" class="form-control" 
                       value="<?php echo htmlspecialchars($admin['telegram_bot'] ?? ''); ?>"
                       placeholder="123456789:ABCdefGHIjklMNOpqrsTUVwxyz">
            </div>
            
            <div class="form-group">
                <label for="telegram_chatid">Chat ID</label>
                <input type="text" id="telegram_chatid" name="telegram_chatid" class="form-control" 
                       value="<?php echo htmlspecialchars($admin['telegram_chatid'] ?? ''); ?>"
                       placeholder="-1001234567890">
            </div>
            
            <?php if (!empty($admin['telegram_bot']) && !empty($admin['telegram_chatid'])): ?>
                <a href="?test_telegram" class="btn btn-secondary">Telegram Bağlantısını Test Et</a>
            <?php endif; ?>
            
            <p style="color: var(--text-muted); font-size: 0.85rem; margin-top: 1rem;">
                <strong>Webhook URL:</strong> <code style="background: rgba(255, 255, 255, 0.05); padding: 0.25rem 0.5rem; border-radius: 4px;">
                    <?php echo BASE_URL; ?>/admin/webhook.php
                </code>
            </p>
            <p style="color: var(--text-muted); font-size: 0.85rem; margin-top: 0.5rem;">
                Bu URL'yi Telegram Bot API'ye webhook olarak kaydedin.
            </p>
        </div>
        
        <div style="margin-bottom: 2rem; padding-top: 2rem; border-top: 1px solid var(--border-color);">
            <h2 style="font-size: 1.3rem; margin-bottom: 1rem; color: var(--text-primary);">Şifre Değiştir</h2>
            
            <div class="form-group">
                <label for="new_password">Yeni Şifre</label>
                <input type="password" id="new_password" name="new_password" class="form-control" 
                       placeholder="Yeni şifrenizi girin (boş bırakın değiştirmemek için)">
            </div>
            
            <div class="form-group">
                <label for="confirm_password">Yeni Şifre (Tekrar)</label>
                <input type="password" id="confirm_password" name="confirm_password" class="form-control" 
                       placeholder="Yeni şifrenizi tekrar girin">
            </div>
        </div>
        
        <button type="submit" class="btn btn-primary btn-block">Ayarları Kaydet</button>
    </form>
</div>

<?php require_once 'includes/footer.php'; ?>

