<?php
$page_title = 'Dashboard';
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../db.php';
require_once 'includes/header.php';

// Get statistics
$total_sales = $pdo->query("SELECT SUM(amount) as total FROM orders WHERE status = 'Teslim Edildi'")->fetch()['total'] ?? 0;
$total_orders = $pdo->query("SELECT COUNT(*) as count FROM orders")->fetch()['count'] ?? 0;
$pending_orders = $pdo->query("SELECT COUNT(*) as count FROM orders WHERE status = 'Bekliyor'")->fetch()['count'] ?? 0;
$total_products = $pdo->query("SELECT COUNT(*) as count FROM products")->fetch()['count'] ?? 0;

// Recent orders
$recent_orders = $pdo->query("
    SELECT o.*, p.name as product_name, u.name, u.surname, u.phone
    FROM orders o
    JOIN products p ON o.product_id = p.id
    JOIN users u ON o.user_id = u.id
    ORDER BY o.created_at DESC
    LIMIT 5
")->fetchAll();
?>

<div class="glass-card">
    <h1 style="font-size: 2rem; margin-bottom: 0.5rem; color: var(--text-primary);">Dashboard</h1>
    <p style="color: var(--text-muted); margin-bottom: 2rem;">Sistem özeti</p>
    
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-value"><?php echo number_format($total_sales, 2); ?> ₺</div>
            <div class="stat-label">Toplam Satış</div>
        </div>
        <div class="stat-card">
            <div class="stat-value"><?php echo $total_orders; ?></div>
            <div class="stat-label">Toplam Sipariş</div>
        </div>
        <div class="stat-card">
            <div class="stat-value" style="color: #fbbf24;"><?php echo $pending_orders; ?></div>
            <div class="stat-label">Bekleyen Sipariş</div>
        </div>
        <div class="stat-card">
            <div class="stat-value"><?php echo $total_products; ?></div>
            <div class="stat-label">Toplam Ürün</div>
        </div>
    </div>
</div>

<div class="glass-card" style="margin-top: 2rem;">
    <h2 style="font-size: 1.5rem; margin-bottom: 1.5rem; color: var(--text-primary);">Son Siparişler</h2>
    
    <?php if (empty($recent_orders)): ?>
        <p style="color: var(--text-muted); text-align: center; padding: 2rem;">Henüz sipariş bulunmamaktadır.</p>
    <?php else: ?>
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Ürün</th>
                        <th>Müşteri</th>
                        <th>Tutar</th>
                        <th>Durum</th>
                        <th>Tarih</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recent_orders as $order): ?>
                        <tr>
                            <td>#<?php echo $order['id']; ?></td>
                            <td><?php echo htmlspecialchars($order['product_name']); ?></td>
                            <td><?php echo htmlspecialchars($order['name'] . ' ' . $order['surname']); ?></td>
                            <td><?php echo number_format($order['amount'], 2); ?> ₺</td>
                            <td>
                                <span class="order-status status-<?php echo strtolower(str_replace(' ', '', $order['status'])); ?>">
                                    <?php echo htmlspecialchars($order['status']); ?>
                                </span>
                            </td>
                            <td><?php echo date('d.m.Y H:i', strtotime($order['created_at'])); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div style="margin-top: 1.5rem; text-align: center;">
            <a href="orders.php" class="btn btn-secondary">Tüm Siparişleri Gör</a>
        </div>
    <?php endif; ?>
</div>

<?php require_once 'includes/footer.php'; ?>

