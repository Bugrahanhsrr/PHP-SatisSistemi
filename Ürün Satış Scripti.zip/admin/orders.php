<?php
$page_title = 'Siparişler';
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../db.php';
require_once 'includes/header.php';

$message = '';
$message_type = '';

// Handle status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $order_id = intval($_POST['order_id']);
    $status = $_POST['status'];
    
    if (in_array($status, ['Bekliyor', 'Teslim Edildi', 'İptal Edildi'])) {
        try {
            $stmt = $pdo->prepare("UPDATE orders SET status = ? WHERE id = ?");
            $stmt->execute([$status, $order_id]);
            $message = 'Sipariş durumu güncellendi.';
            $message_type = 'success';
        } catch (Exception $e) {
            $message = 'Hata: ' . $e->getMessage();
            $message_type = 'error';
        }
    }
}

// Handle admin message
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_message'])) {
    $order_id = intval($_POST['order_id']);
    $admin_message = trim($_POST['admin_message']);
    
    try {
        $stmt = $pdo->prepare("UPDATE orders SET admin_message = ? WHERE id = ?");
        $stmt->execute([$admin_message, $order_id]);
        $message = 'Mesaj gönderildi.';
        $message_type = 'success';
    } catch (Exception $e) {
        $message = 'Hata: ' . $e->getMessage();
        $message_type = 'error';
    }
}

// Fetch all orders
$orders = $pdo->query("
    SELECT o.*, p.name as product_name, p.image_url, u.name, u.surname, u.phone
    FROM orders o
    JOIN products p ON o.product_id = p.id
    JOIN users u ON o.user_id = u.id
    ORDER BY o.created_at DESC
")->fetchAll();

// Get order for edit
$edit_order = null;
if (isset($_GET['edit'])) {
    $id = intval($_GET['edit']);
    $stmt = $pdo->prepare("
        SELECT o.*, p.name as product_name, p.image_url, u.name, u.surname, u.phone
        FROM orders o
        JOIN products p ON o.product_id = p.id
        JOIN users u ON o.user_id = u.id
        WHERE o.id = ?
    ");
    $stmt->execute([$id]);
    $edit_order = $stmt->fetch();
}
?>

<div class="glass-card">
    <h1 style="font-size: 2rem; margin-bottom: 0.5rem; color: var(--text-primary);">Siparişler</h1>
    <p style="color: var(--text-muted); margin-bottom: 2rem;">Tüm siparişleri görüntüleyin ve yönetin</p>
    
    <?php if ($message): ?>
        <div class="alert alert-<?php echo $message_type; ?>"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>
    
    <?php if (empty($orders)): ?>
        <p style="color: var(--text-muted); text-align: center; padding: 2rem;">Henüz sipariş bulunmamaktadır.</p>
    <?php else: ?>
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Ürün</th>
                        <th>Müşteri</th>
                        <th>Telefon</th>
                        <th>Tutar</th>
                        <th>Durum</th>
                        <th>Tarih</th>
                        <th>İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orders as $order): ?>
                        <tr>
                            <td>#<?php echo $order['id']; ?></td>
                            <td>
                                <div style="display: flex; align-items: center; gap: 0.5rem;">
                                    <img src="<?php echo htmlspecialchars($order['image_url']); ?>" 
                                         alt="<?php echo htmlspecialchars($order['product_name']); ?>" 
                                         style="width: 40px; height: 40px; object-fit: cover; border-radius: var(--border-radius);"
                                         onerror="this.src='https://via.placeholder.com/40x40/101826/57F287?text=No+Image'">
                                    <span><?php echo htmlspecialchars($order['product_name']); ?></span>
                                </div>
                            </td>
                            <td><?php echo htmlspecialchars($order['name'] . ' ' . $order['surname']); ?></td>
                            <td><?php echo htmlspecialchars($order['phone']); ?></td>
                            <td><?php echo number_format($order['amount'], 2); ?> ₺</td>
                            <td>
                                <span class="order-status status-<?php echo strtolower(str_replace(' ', '', $order['status'])); ?>">
                                    <?php echo htmlspecialchars($order['status']); ?>
                                </span>
                            </td>
                            <td><?php echo date('d.m.Y H:i', strtotime($order['created_at'])); ?></td>
                            <td>
                                <a href="?edit=<?php echo $order['id']; ?>" class="btn btn-secondary" style="padding: 0.5rem 1rem; font-size: 0.85rem;">Yönet</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<!-- Order Management Modal -->
<?php if ($edit_order): ?>
<div id="orderModal" class="modal active">
    <div class="modal-content">
        <div class="modal-header">
            <h2 class="modal-title">Sipariş Yönetimi - #<?php echo $edit_order['id']; ?></h2>
            <button class="modal-close" onclick="window.location.href='orders.php'">&times;</button>
        </div>
        
        <div style="margin-bottom: 2rem;">
            <div style="background: rgba(255, 255, 255, 0.05); border-radius: var(--border-radius); padding: 1.5rem; margin-bottom: 1rem;">
                <h3 style="color: var(--text-primary); margin-bottom: 1rem; font-size: 1.2rem;">Sipariş Bilgileri</h3>
                <p style="color: var(--text-muted); margin-bottom: 0.5rem;"><strong style="color: var(--text-primary);">Ürün:</strong> <?php echo htmlspecialchars($edit_order['product_name']); ?></p>
                <p style="color: var(--text-muted); margin-bottom: 0.5rem;"><strong style="color: var(--text-primary);">Müşteri:</strong> <?php echo htmlspecialchars($edit_order['name'] . ' ' . $edit_order['surname']); ?></p>
                <p style="color: var(--text-muted); margin-bottom: 0.5rem;"><strong style="color: var(--text-primary);">Telefon:</strong> <?php echo htmlspecialchars($edit_order['phone']); ?></p>
                <p style="color: var(--accent); font-size: 1.3rem; font-weight: 600; margin-top: 0.5rem;">
                    <?php echo number_format($edit_order['amount'], 2); ?> ₺
                </p>
            </div>
        </div>
        
        <form method="POST" action="" style="margin-bottom: 2rem;">
            <input type="hidden" name="update_status" value="1">
            <input type="hidden" name="order_id" value="<?php echo $edit_order['id']; ?>">
            
            <div class="form-group">
                <label for="status">Durum</label>
                <select id="status" name="status" class="form-control" required>
                    <option value="Bekliyor" <?php echo $edit_order['status'] === 'Bekliyor' ? 'selected' : ''; ?>>Bekliyor</option>
                    <option value="Teslim Edildi" <?php echo $edit_order['status'] === 'Teslim Edildi' ? 'selected' : ''; ?>>Teslim Edildi</option>
                    <option value="İptal Edildi" <?php echo $edit_order['status'] === 'İptal Edildi' ? 'selected' : ''; ?>>İptal Edildi</option>
                </select>
            </div>
            
            <button type="submit" class="btn btn-primary btn-block">Durumu Güncelle</button>
        </form>
        
        <form method="POST" action="">
            <input type="hidden" name="send_message" value="1">
            <input type="hidden" name="order_id" value="<?php echo $edit_order['id']; ?>">
            
            <div class="form-group">
                <label for="admin_message">Müşteriye Mesaj</label>
                <textarea id="admin_message" name="admin_message" class="form-control" rows="4" 
                          placeholder="Müşteriye göndermek istediğiniz mesajı buraya yazın..."><?php echo htmlspecialchars($edit_order['admin_message'] ?? ''); ?></textarea>
            </div>
            
            <button type="submit" class="btn btn-secondary btn-block">Mesaj Gönder</button>
        </form>
    </div>
</div>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>

