<?php
/**
 * Telegram Bot Integration
 * Handles sending notifications and processing inline button callbacks
 */

/**
 * Send order notification to Telegram
 */
function sendOrderNotification($pdo, $order_id) {
    // Get admin settings
    $stmt = $pdo->query("SELECT telegram_bot, telegram_chatid FROM admin WHERE telegram_bot IS NOT NULL AND telegram_chatid IS NOT NULL LIMIT 1");
    $admin = $stmt->fetch();
    
    if (!$admin || empty($admin['telegram_bot']) || empty($admin['telegram_chatid'])) {
        return false;
    }
    
    // Get order details
    $stmt = $pdo->prepare("
        SELECT o.*, p.name as product_name, u.name, u.surname, u.phone
        FROM orders o
        JOIN products p ON o.product_id = p.id
        JOIN users u ON o.user_id = u.id
        WHERE o.id = ?
    ");
    $stmt->execute([$order_id]);
    $order = $stmt->fetch();
    
    if (!$order) {
        return false;
    }
    
    $bot_token = $admin['telegram_bot'];
    $chat_id = $admin['telegram_chatid'];
    
    $message = "Yeni Sipariş! 💸\n\n";
    $message .= "Kullanıcı: {$order['name']} {$order['surname']}\n";
    $message .= "Telefon: {$order['phone']}\n";
    $message .= "Ürün: {$order['product_name']}\n";
    $message .= "Tutar: " . number_format($order['amount'], 2) . " ₺\n";
    $message .= "Sipariş No: #{$order['id']}";
    
    // Inline keyboard
    $inline_keyboard = [
        'inline_keyboard' => [
            [
                [
                    'text' => 'Onayla ✅',
                    'callback_data' => 'approve_' . $order_id
                ],
                [
                    'text' => 'Reddet ❌',
                    'callback_data' => 'reject_' . $order_id
                ]
            ]
        ]
    ];
    
    $data = [
        'chat_id' => $chat_id,
        'text' => $message,
        'parse_mode' => 'HTML',
        'reply_markup' => json_encode($inline_keyboard)
    ];
    
    $url = "https://api.telegram.org/bot{$bot_token}/sendMessage";
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    return $response;
}

/**
 * Process Telegram callback query
 */
function processTelegramCallback($pdo, $callback_data, $chat_id = null) {
    // Get admin settings
    $stmt = $pdo->query("SELECT telegram_bot FROM admin WHERE telegram_bot IS NOT NULL LIMIT 1");
    $admin = $stmt->fetch();
    
    if (!$admin || empty($admin['telegram_bot'])) {
        return false;
    }
    
    $bot_token = $admin['telegram_bot'];
    
    // Parse callback data
    if (strpos($callback_data, 'approve_') === 0) {
        $order_id = intval(str_replace('approve_', '', $callback_data));
        $status = 'Teslim Edildi';
        $action = 'onaylandı';
    } elseif (strpos($callback_data, 'reject_') === 0) {
        $order_id = intval(str_replace('reject_', '', $callback_data));
        $status = 'İptal Edildi';
        $action = 'iptal edildi';
    } else {
        return false;
    }
    
    // Update order status
    $stmt = $pdo->prepare("UPDATE orders SET status = ? WHERE id = ?");
    $stmt->execute([$status, $order_id]);
    
    // Get order info for confirmation message
    $stmt = $pdo->prepare("
        SELECT o.*, p.name as product_name, u.name, u.surname
        FROM orders o
        JOIN products p ON o.product_id = p.id
        JOIN users u ON o.user_id = u.id
        WHERE o.id = ?
    ");
    $stmt->execute([$order_id]);
    $order = $stmt->fetch();
    
    if ($order) {
        // Send confirmation message back
        $confirmation = "Sipariş #{$order_id} {$action}.\n";
        $confirmation .= "Ürün: {$order['product_name']}\n";
        $confirmation .= "Kullanıcı: {$order['name']} {$order['surname']}";
        
        return [
            'success' => true,
            'message' => $confirmation,
            'chat_id' => $chat_id,
            'bot_token' => $bot_token
        ];
    }
    
    return false;
}

/**
 * Send message via Telegram
 */
function sendTelegramMessage($bot_token, $chat_id, $message) {
    $url = "https://api.telegram.org/bot{$bot_token}/sendMessage";
    
    $data = [
        'chat_id' => $chat_id,
        'text' => $message,
        'parse_mode' => 'HTML'
    ];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    return json_decode($response, true);
}

